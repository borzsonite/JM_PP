package jm.task.core.jdbc;

import jm.task.core.jdbc.util.Util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {
        // реализуйте алгоритм здесь
        Connection connection = Util.getConnection();
        try {
            Statement statement = connection.createStatement();
            String createTable = "CREATE TABLE User(\n" +
                    "    id long,\n" +
                    "    name varchar(30),\n" +
                    "    last_name varchar(30),\n" +
                    "    age tinyint\n" +
                    ")";
            statement.execute(createTable);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
       }
}
